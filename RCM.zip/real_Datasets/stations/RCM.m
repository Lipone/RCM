% with a standard non-delayed RC of dimension 200
function f = NCM(data1, data2, dim, len, scale, norm1, norm2)

% Check default values for norm1 and norm2
if nargin < 6  % If norm1 is not provided, set it to true
    norm1 = true;
end
if nargin < 7  % If norm2 is not provided, set it to true
    norm2 = true;
end

data = [data1; data2];
Data = data;

if norm1 == true
    [Data, ps] = mapstd(data); % Data normalization
end

resSize = 200; % Number of RC neurons

load Reservior_Parameter.mat

gamma = 0.44; % Leaky rate
% gamma = 0.1; % Leaky rate

initialen = 1000;
trainlen = len - initialen;
len = initialen + trainlen;
testlen = 0;

r = zeros(resSize, 1);
rtotal1 = zeros(resSize, len + testlen);
rtotal2 = zeros(resSize, len + testlen);

% Training period
for i = 1:len + testlen
    ut = Data(1:dim, i);
    r = (1 - gamma) * r + gamma * (tanh(Win * ut + Wres * r));
    rtotal1(:, i) = r;
end

r = zeros(resSize, 1);
for i = 1:len + testlen
    ut = Data(dim+1:2*dim, i);
    r = (1 - gamma) * r + gamma * (tanh(Win * ut + Wres * r));
    rtotal2(:, i) = r;
end

% Half of the neurons are nonlinear (even terms)
rtotal1(2:2:end, :) = rtotal1(2:2:end, :).^2;
rtotal2(2:2:end, :) = rtotal2(2:2:end, :).^2;
rtrain1 = rtotal1(:, initialen+1:len);
rtrain2 = rtotal2(:, initialen+1:len);

Data1 = rtotal1;
Data2 = rtotal2;

if norm2 == true
    [Data1, ps] = mapstd(rtotal1); % Data normalization
    [Data2, ps] = mapstd(rtotal2); % Data normalization
end

% Data1 = rtrain1;
% Data2 = rtrain2;

resSize = 1000; % Number of RC neurons

load("Embedding_reservior_parameter.mat")
gamma = 0.9;

initialen = 1000; % 1000
trainlen = len - initialen; % 1000
len = initialen + trainlen;
testlen = 0; % 1000

r = zeros(resSize, 1);
rtotal = zeros(resSize, len + testlen);

% Training period
for i = 1:len + testlen
    ut = Data2(:, i);
    r = (1 - gamma) * r + gamma * (tanh(Win * ut + Wres * r));
    rtotal(:, i) = r;
end

% Half of the neurons are nonlinear (even terms)
rtotal(2:2:end, :) = rtotal(2:2:end, :).^2;

rtrain = rtotal(:, initialen+1:len);

% Tikhonov regularization to solve Wout
traindata = Data1(:, initialen+1:len);

beta = 1e-5; % Regularization parameter
Wout = ((rtrain * rtrain' + beta * eye(resSize)) \ (rtrain * traindata'))';
trainoutput = Wout * rtrain;
Mse1 = mean(mean((trainoutput - traindata).^2, 2));

% Calculate the normalized mean square error
dataset_mean = mean(traindata(:));
dataset_variance = mean((traindata(:) - dataset_mean).^2);
NMSE3 = Mse1 / dataset_variance;

% Calculate the NCM index
INDEX = exp(-scale * NMSE3);

f = INDEX;
end
