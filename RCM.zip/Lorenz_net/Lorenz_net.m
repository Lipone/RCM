% Parameter settings
clc;
clear;
sigma = 10;
rho = 28;
beta = 8/3;
num_nodes = 10;  % Number of Lorenz systems

% Define lists of coupling strengths and connection probabilities
coupling_strengths = [0.5,1];
connection_probs = [0.1, 0.3, 0.5];

% Initial conditions (10 Lorenz systems, each with 3 variables)
x0 = rand(3 * num_nodes, 1);  % Generate initial conditions, length 3*num_nodes

% Time range
tspan = linspace(0, 500, 50000);

% Nested loops to calculate for different coupling strengths and connection probabilities
for coupling_strength = coupling_strengths
    for connection_prob = connection_probs
        numNodes = num_nodes;
        NCMindex = zeros(3, numNodes, numNodes);
        GCindex = zeros(3, numNodes, numNodes);
        TEindex = zeros(3, numNodes, numNodes);
        CCMindex = zeros(3, numNodes, numNodes);
        for run = 1:3
            % Generate random adjacency matrix
            adj_matrix = rand(num_nodes) < connection_prob;  
            for i = 1:num_nodes
                adj_matrix(i, i) = 0;  % Ensure no self-loops
            end
    
            % Simulate system dynamics
            [t, X] = ode45(@(t,x) lorenz_system(t, x, sigma, rho, beta, coupling_strength, num_nodes, adj_matrix), tspan, x0);
    
            % Initialize the return matrix
            num_time_steps = length(t);  % Number of time steps
            node_states = zeros(num_nodes, num_time_steps, 3);  % 3D matrix: nodes x time steps x states
    
            % Populate the return matrix, each node has x, y, z states
            for i = 1:num_nodes
                node_states(i, :, 1) = X(:, 3*i-2);  % x state
                node_states(i, :, 2) = X(:, 3*i-1);  % y state
                node_states(i, :, 3) = X(:, 3*i);    % z state
            end
    
            % Save file with a name generated based on coupling strength and connection probability
            output = node_states;
            connectivityMatrix(run) = adj_matrix;

            p = 6; k = 5; Thei = 10;
            
            for i = 1:numNodes
                for j = 1:numNodes
                    if i ~= j
                        data1 = squeeze(output(i,:,:))';  
                        data2 = squeeze(output(j,:,:))';
                        NCMindex(run,j,i) = RCM(data1, data2);  % NCM
                        GCindex(run,j,i) = GCmy(data1(1,1:7000), data2(1,1:7000), p);  % GC
                        TEindex(run,j,i) = TEmy(data1(1,1:7000), data2(1,1:7000), p, k, Thei);  % TE
                        CCMindex(run,j,i) = MCM(data1(1,1:7000), data2(1,1:7000), p, Thei);  % CCM
                    end
                end
            end
        end

        save(sprintf("NEW_output_coupling_%d_prob_%.1f.mat", coupling_strength, connection_prob), ...
            "connectivityMatrix", "NCMindex", "GCindex", "TEindex", "CCMindex");
    end
end

% Function to plot the average ROC curve with standard deviation
function avg_auc = plot_avg_roc_with_std(predict_list, ground_truth_list, color, name)
    % INPUTS
    % predict_list        - List of predictions from multiple classifiers, size [num_classifiers x num_samples]
    % ground_truth_list   - List of ground truth labels from multiple classifiers, size [num_classifiers x num_samples]
    % color               - Color of the ROC curve
    % name                - Name of the curve
    
    % Define a unified false positive rate range
    num_points = 1000;
    mean_fpr = linspace(0, 1, num_points); % Define a uniform range of false positive rates from 0 to 1
    tprs = zeros(length(predict_list), num_points); % Store interpolated TPR for each classifier
    aucs = zeros(1, length(predict_list)); % Store AUC for each classifier
    
    % Iterate through each classifier or cross-validation fold
    for i = 1:length(predict_list)
        predict = predict_list{i}; % Get predictions from the i-th classifier
        ground_truth = ground_truth_list{i}; % Get ground truth labels for the i-th classifier
        
        % Calculate the ROC curve for this classifier
        [fpr, tpr, ~, auc] = perfcurve(ground_truth, predict, 1);
        aucs(i) = auc; % Store AUC
        % Remove duplicate FPR values to ensure smooth interpolation
        [fpr, unique_idx] = unique(fpr);  % Get unique FPR values and corresponding indices
        tpr = tpr(unique_idx);  % Keep TPR values corresponding to unique FPR
        
        % Interpolate to the unified false positive rate points
        tprs(i, :) = interp1(fpr, tpr, mean_fpr, 'linear', 'extrap');
    end
    
    % Calculate average TPR
    mean_tpr = mean(tprs, 1); % Average TPR across all classifiers
    std_tpr = std(tprs, 0, 1); % Standard deviation of TPR across all classifiers
    avg_auc = mean(aucs); % Calculate the average AUC
    
    % Plot the average ROC curve
    plot(mean_fpr, mean_tpr, 'LineWidth', 2, 'Color', color);
    hold on;
    
    % Plot the standard deviation area (as a shaded region)
    fill([mean_fpr fliplr(mean_fpr)], [mean_tpr+std_tpr fliplr(mean_tpr-std_tpr)], ...
        color, 'FaceAlpha', 0.2, 'EdgeColor', 'none');
    
    xlim([0 1]);
    ylim([0 1]);
    xlabel('False Positive Rate');
    ylabel('True Positive Rate');
    title(['Average ROC: ' name]);
    grid on;
    
    % Display AUC as text on the plot
    text(0.6, 0.2, sprintf('AUC = %.3f', avg_auc), 'FontSize', 12, 'Color', color);
end

% Define differential equations for the coupled Lorenz system
function dxdt = lorenz_system(t, x, sigma, rho, beta, coupling_strength, num_nodes, adj_matrix)
    dxdt = zeros(3 * num_nodes, 1);  % Initialize derivative vector

    % Iterate through each node and calculate its dynamics
    for i = 1:num_nodes
        x_i = x(3*i-2);
        y_i = x(3*i-1);
        z_i = x(3*i);

        % Lorenz system equations
        dx = sigma * (y_i - x_i);
        dy = x_i * (rho - z_i) - y_i;
        dz = x_i * y_i - beta * z_i;

        % Coupling term: calculate coupling with connected nodes (based on adjacency matrix)
        coupling_x = 0;
        for j = 1:num_nodes
            if adj_matrix(i, j) == 1  % If there is a connection between node i and node j
                x_j = x(3*j-2);
                coupling_x = coupling_x + coupling_strength * x_j;
            end
        end

        % Update current node's equations
        dxdt(3*i-2) = dx + coupling_x;  % Add coupling term to x direction
        dxdt(3*i-1) = dy;  % y direction remains uncoupled
        dxdt(3*i) = dz;    % z direction remains uncoupled
    end
end
